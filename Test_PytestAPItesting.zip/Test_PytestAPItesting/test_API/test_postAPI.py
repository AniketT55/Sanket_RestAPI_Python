import pytest
import requests
import unittest

class PostApiTest(unittest.TestCase):

    def test_post(self):
        data = {'name': 'Aniket',
                'job': 'QA'}
        resp = requests.post(url="https://reqres.in/api/users", data=data)
        resp_data = resp.json()
        print(resp_data)
        assert resp.status_code == 201, "Status code is not 201"
        assert resp_data['name'] == 'Aniket', "Name is incorrect"
        assert resp_data['job'] == 'QA', "Job is incorrect"


    def test_newpost(self):
        new = {'email' : 'anikettest@gmail.com'}
        new_resp = requests.post(url= "https://reqres.in/api/login", data=new)
        new_data = new_resp.json()
        print(new_data)
        assert new_resp.status_code == 400, "Status code is not 400"
        assert new_data['error'] == 'Missing password'


if __name__ == '__main__':
    unittest.main()
