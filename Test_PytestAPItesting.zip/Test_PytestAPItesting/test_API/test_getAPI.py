import pytest
import requests



# from test_API.test_fixture import open_url
# from test_API.test_fixture import json_test

# class GetApiTest:

@pytest.fixture()
def open_url():
    global res
    res = requests.get("https://reqres.in/api/users?page=2")

@pytest.fixture()
def json_test():
     global value
     value = res.json()

def test_statuscode(open_url):
     a = res.status_code
     assert a == 200, "Test case failed"
     #    test_statuscode.__doc__ = "Verify the status code as 200: "


def test_header(open_url):
      #    head = res.headers
      #    print(head)
      assert res.headers['Content-Type'] == 'application/json; charset=utf-8'


def test_objvalue(open_url, json_test):
      #    res_body = res.json()
      assert value["page"] == 2


def test_innerloop(open_url, json_test):
      #    res_innerbody = res.json()
      assert value["data"][2]["id"] == 9

# if __name__ == '__main__':
#     unittest.main()
