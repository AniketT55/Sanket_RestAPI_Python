import pytest
import requests



@pytest.fixture()
def open_url(self):
    global res
    res = requests.get("https://reqres.in/api/users?page=2")


@pytest.fixture()
def json_test(self):
    global value
    value = res.json()